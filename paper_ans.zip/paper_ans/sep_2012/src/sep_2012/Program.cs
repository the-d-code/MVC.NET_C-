﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sep_2012
{
    public class Program
    {
        public void Main(string[] args)
        {
            
        }
    }
}
