﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DICT\Documents\DB.mdf;Integrated Security=True;Connect Timeout=30")
        SqlCommand cmd = new SqlCommand();
        DataSet ds = new DataSet();
        SqlDataAdapter adp;
        protected void Page_Load(object sender, EventArgs e)
        {
          if(con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
            {
                
            }
            
      
        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            ds.Clear();
            con.open();
            cmd = new SqlCommand("select * form tblbook", con);
            Adp = new SqlDataAdapter(cmd);
            cn.close();
            fillgrid();

            grdorder.datasource = ds;
            grdorder.databind = ds;
            



        }
    }
}