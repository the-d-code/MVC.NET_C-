﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace MVCICT2.Models
{
    public partial class Furnitures
    {
        public int FurnitureId { get; set; }
        public string FurnitureName { get; set; }
        public int FurnitureRate { get; set; }
        public string FurnitureDescription { get; set; }
        public int CategoryId { get; set; }

        public virtual Categories Category { get; set; }
    }
}
