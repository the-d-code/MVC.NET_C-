﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCICT2.Models
{
    public class Product
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public int pRate { get; set; }
        public Category pCategory { get; set; }
        public string pDescription { get; set; }
    }
}
