﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVCICT2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCICT2.Controllers
{
    public class CategoryController : Controller
    {
        private static List<Category> categories = new List<Category>();

        public CategoryController()
        {
            if(categories.Count == 0)
            {

                categories.Add(new Category { CategoryID = 1,CategoryName="abc"});
                categories.Add(new Category { CategoryID = 2,CategoryName="xyz"});

            }
        }
        // GET: CategoryController
        public ActionResult Index()
        {
            return View(categories);
        }

        // GET: CategoryController/Details/5
        public ActionResult Details(int id)
        {
            Category cat = categories.FirstOrDefault(c => c.CategoryID == id);
            return View(cat);
        }

        // GET: CategoryController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CategoryController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Category collection)
        {
            try
            {
                Category c = new Category
                {
                    CategoryID = categories.Max(c => c.CategoryID) + 1,
                    CategoryName = collection.CategoryName,
                };
                categories.Add(c);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CategoryController/Edit/5
        public ActionResult Edit(int id)
        {
            var cat = categories.FirstOrDefault(c => c.CategoryID == id);

            return View(cat);
        }

        // POST: CategoryController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Category collection)
        {
            try
            {
                var cat = categories.FirstOrDefault(c => c.CategoryID == id);
                cat.CategoryName = collection.CategoryName;
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CategoryController/Delete/5
        public ActionResult Delete(int id)
        {
            var cat = categories.FirstOrDefault(c => c.CategoryID == id);
            categories.Remove(cat);
            return View();
        }

        // POST: CategoryController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
