﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVCICT2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCICT2.Controllers
{
    public class ProductCategory
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public int pRate { get; set; }
        public string pCategory { get; set; }
        public string pDescription { get; set; }
    }
    public class ProductController : Controller
    {
        private static List<Product> products = new List<Product>();
        private static List<Category> categories = new List<Category>();

        public ProductController()
        {
            if (categories.Count == 0)
            {
                categories.Add(new Category { CategoryID = 1, CategoryName = "man" });
                categories.Add(new Category { CategoryID = 2, CategoryName = "woman" });
                categories.Add(new Category { CategoryID = 3, CategoryName = "child" });

            }

            if (products.Count == 0)
            {

                products.Add(new Product { pId = 1, pName = "soap", pRate = 2000, pCategory = categories.SingleOrDefault(c => c.CategoryName.Equals("child")), pDescription = "this is product" });
                products.Add(new Product { pId = 2, pName = "soap", pRate = 3000, pCategory = categories.SingleOrDefault(c => c.CategoryName.Equals("woman")), pDescription = "this is product shampoo" });
                products.Add(new Product { pId = 3, pName = "brush", pRate = 4000, pCategory = categories.SingleOrDefault(c => c.CategoryName.Equals("man")), pDescription = "this is product brush" });
                products.Add(new Product { pId = 4, pName = "toothpaste", pRate = 5000, pCategory = categories.SingleOrDefault(c => c.CategoryName.Equals("child")), pDescription = "this is product toothpaste" });
            }
            else
            {

            }
        }
        // GET: ProductController
        public ActionResult Index()
        {

            return View(products);
        }

        // GET: ProductController/Details/5
        public ActionResult Details(int id)
        {
            Product product = products.FirstOrDefault(p => p.pId == id);

            return View(product);
        }

        // GET: ProductController/Create
        public ActionResult Create()
        {
            List<SelectListItem> catList = new List<SelectListItem>();
            foreach (var cat in categories)
            {
                catList.Add(new SelectListItem { Text = cat.CategoryName, Value = cat.CategoryID.ToString() });
            }
            ViewBag.catList = catList;

            return View();
        }

        // POST: ProductController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(ProductCategory product)
        {
            try
            {
                Product p = new Product
                {
                    pId = products.Max(c => c.pId) + 1,
                    pName = product.pName,
                    pCategory = categories.SingleOrDefault(c => c.CategoryID.ToString().Equals(product.pCategory)),
                    pRate = product.pRate,
                    pDescription = product.pDescription,

                };
                products.Add(p);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductController/Edit/5
        public ActionResult Edit(int id)
        {
            List<SelectListItem> catList = new List<SelectListItem>();
            foreach (var cat in categories)
            {
                catList.Add(new SelectListItem { Text = cat.CategoryName, Value = cat.CategoryID.ToString() });
            }
            ViewBag.catList = catList;

            Product product = products.Find(p => p.pId == id);
            return View(product);
        }

        // POST: ProductController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, ProductCategory product)
        {
            try
            {
                Product p1 = products.Find(p => p.pId == id);

                p1.pName = product.pName;
                p1.pRate = product.pRate;
                p1.pCategory = categories.SingleOrDefault(c => c.CategoryID.ToString().Equals(product.pCategory));
                p1.pDescription = product.pDescription;

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductController/Delete/5
        public ActionResult Delete(int id)
        {
            Product p = products.Find(po => po.pId == id);
            products.Remove(p);
            return View();
        }

        // POST: ProductController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
