﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using mvc2Ict2.Models;

namespace mvc2Ict2.Controllers
{

    public class FurnituresController : Controller
    {
        private readonly FurnitureDBContext _context;

        public FurnituresController(FurnitureDBContext context)
        {
            _context = context;
        }

        // GET: Furnitures
        public async Task<IActionResult> Index(List<Furnitures> ?searchResult)
        {
            if(searchResult.Count != 0)
            {
                return View( searchResult.ToList());
            }
            var furnitureDBContext = _context.Furnitures.Include(f => f.Category);
            return View(await furnitureDBContext.ToListAsync());
        }

        // GET: Furnitures/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var furnitures = await _context.Furnitures
                .Include(f => f.Category)
                .FirstOrDefaultAsync(m => m.FurnitureId == id);
            if (furnitures == null)
            {
                return NotFound();
            }

            return View(furnitures);
        }

        // GET: Furnitures/Create
        public IActionResult Create()
        {
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryName");
            return View();
        }

        // POST: Furnitures/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FurnitureId,FurnitureName,FurnitureRate,FurnitureDescription,CategoryId")] Furnitures furnitures)
        {
            if (ModelState.IsValid)
            {
                _context.Add(furnitures);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryName", furnitures.CategoryId);
            return View(furnitures);
        }

        // GET: Furnitures/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var furnitures = await _context.Furnitures.FindAsync(id);
            if (furnitures == null)
            {
                return NotFound();
            }
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryId", furnitures.CategoryId);
            return View(furnitures);
        }

        // POST: Furnitures/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FurnitureId,FurnitureName,FurnitureRate,FurnitureDescription,CategoryId")] Furnitures furnitures)
        {
            if (id != furnitures.FurnitureId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(furnitures);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FurnituresExists(furnitures.FurnitureId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryId", furnitures.CategoryId);
            return View(furnitures);
        }

        // GET: Furnitures/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var furnitures = await _context.Furnitures
                .Include(f => f.Category)
                .FirstOrDefaultAsync(m => m.FurnitureId == id);
            if (furnitures == null)
            {
                return NotFound();
            }

            return View(furnitures);
        }

        // POST: Furnitures/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var furnitures = await _context.Furnitures.FindAsync(id);
            _context.Furnitures.Remove(furnitures);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FurnituresExists(int id)
        {
            return _context.Furnitures.Any(e => e.FurnitureId == id);
        }
        //------------------------------------------------------------
        public IActionResult SearchByName()
        {
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryId");
            return View();
        }
        public IActionResult SearchByRateRange()
        {
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryId");
            return View();
        }
        public IActionResult SearchByCategory()
        {
            ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryName");
            return View();
        }

        // POST: Furnitures/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SearchByName(string furnitureName)
        {
            var searchResult =await _context.Furnitures.Where(f=>f.FurnitureName.Contains(furnitureName)).ToListAsync();
            return View("Index",searchResult);
        } 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SearchByRateRange(int minRate, int maxRate)
        {
            var searchResult =await _context.Furnitures.Where(f=>f.FurnitureRate<=maxRate && f.FurnitureRate>=minRate).ToListAsync();
            return View("Index",searchResult);
        } 
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SearchByCategory(Furnitures f)
        {
            var searchResult =await _context.Furnitures.Where(a=>a.Category.CategoryId== f.CategoryId).Include(f => f.Category).ToListAsync();
            return View("Index",searchResult);
        }



    }
}
