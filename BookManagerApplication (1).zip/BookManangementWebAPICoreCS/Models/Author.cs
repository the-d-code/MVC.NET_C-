﻿namespace BookManangementWebAPICoreCS.Models
{
    public class Author
    {
        public int AuthorID { get; set; }
        public string AutherName { get; set; }

    }
}
