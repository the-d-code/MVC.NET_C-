﻿namespace BookManangementWebAPICoreCS.Models
{
    public class Book
    {
        public int AccNo { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int Price { get; set; }
        public string Publisher { get; set; }
    }
}
