﻿namespace BookManangementWebAPICoreCS.Models
{
    public struct AuthorTitle
    {
        public string Author { get; set; }
        public string Title { get; set; }
    }
}
