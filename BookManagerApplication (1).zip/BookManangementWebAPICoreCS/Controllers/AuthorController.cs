﻿using BookManangementWebAPICoreCS.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookManangementWebAPICoreCS.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorController : ControllerBase
    {
        private static List<Author> authors = new List<Author>();

        public AuthorController()
        {
            if (authors.Count == 0)
            {
                authors.Add(new Author { AuthorID = 1, AutherName = "ABC" });
                authors.Add(new Author { AuthorID = 2, AutherName = "PRQ" });
            }
        }

        // GET: api/<AuthorController>
        [HttpGet]
        public async Task<List<Author>> Get()
        {
            return  authors.ToList<Author>();
        }

        // GET api/<AuthorController>/5
        [HttpGet("{id}")]
        public Author Get(int id)
        {
            return authors.SingleOrDefault(a => a.AuthorID == id);
        }

        // GET api/<AuthorController>/5
        [HttpGet("searchByName/{name}")]
        public Author Get(string name)
        {
            return authors.SingleOrDefault(a => a.AutherName.Contains(name));
        }

        // POST api/<AuthorController>
        [HttpPost]
        public void Post([FromBody] Author newAuthor)
        {
            if (authors.SingleOrDefault(a=>a.AuthorID == newAuthor.AuthorID) == null)
            {
                authors.Add(newAuthor);
            }
        }

        // PUT api/<AuthorController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Author updatedAuthor)
        {
            Author authorToUpdate = Get(id);
            if (authorToUpdate != null)
            {
                authorToUpdate.AutherName = updatedAuthor.AutherName;
            }

        }

        // DELETE api/<AuthorController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            Author authorToDelete = Get(id);
            if (authorToDelete != null)
            {
                authors.Remove(authorToDelete);
            }
        }

    }
}
