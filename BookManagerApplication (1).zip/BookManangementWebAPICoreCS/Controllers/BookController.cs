﻿using BookManangementWebAPICoreCS.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookManangementWebAPICoreCS.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private static List<Book> bookList = new List<Book>();

        public BookController()
        {
            if (bookList.Count == 0)
            {
                bookList.Add(new Book { AccNo = 1001, Author = "Yashwant", Title = "C Programming", Publisher = "BPB", Price = 400 });
                bookList.Add(new Book { AccNo = 1002, Author = "Kumar", Title = "Learning C++", Publisher = "TMH", Price = 700 });
            }
        }

        // GET: api/<BookController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<BookController>/5
        [HttpGet("{id}")]
        //public (string, string) Get(int id)
        public AuthorTitle Get(int id)
        {
            //(string s1, string s2) = (s1 = "value", s2 = "V1");
            //return (s1, s2);

            //var book = bookList.Where(b => b.AccNo == id).First();
            //return (book.Author, book.Title);

            var book = bookList.Where(b => b.AccNo == id).First();

            AuthorTitle at = new AuthorTitle();
            at.Author = book.Author;
            at.Title = book.Title;

            return at;
        }

        // GET api/<BookController>/5
        [HttpGet("{price}/{publisher}")]
        public List<Book> Get(int price, string publisher)
        {
            return bookList.Where(b => b.Price > price)
                .Where(b => b.Publisher.Contains(publisher)).ToList();
        }

        //// GET api/<BookController>/5
        //[HttpGet("{id}")]
        //public string Get(string title, string author)
        //{
        //    return "value";
        //}

        // POST api/<BookController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<BookController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<BookController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
