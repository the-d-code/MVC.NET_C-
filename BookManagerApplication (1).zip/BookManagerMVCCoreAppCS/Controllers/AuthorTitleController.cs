﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using BookManagerMVCCoreAppCS.Models;
using System.Threading.Tasks;

namespace BookManagerMVCCoreAppCS.Controllers
{
    public class AuthorTitleController : Controller
    {
        private string BaseURL = @"http://localhost:5000/api/book";  

        // GET: AuthorTitleController
        public ActionResult Index()
        {
            return View();
        }

        // GET: AuthorTitleController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            Title_Author title_author = null;

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(BaseURL + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    title_author = JsonConvert.DeserializeObject<Title_Author>(apiResponse);
                }
            }

            return View(title_author);
        }

        // GET: AuthorTitleController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AuthorTitleController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AuthorTitleController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: AuthorTitleController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AuthorTitleController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: AuthorTitleController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
