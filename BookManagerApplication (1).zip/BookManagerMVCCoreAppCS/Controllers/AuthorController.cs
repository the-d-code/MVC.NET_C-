﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using BookManagerMVCCoreAppCS.Models;
using Newtonsoft.Json;
using System.Text;

namespace BookManagerMVCCoreAppCS.Controllers
{
    public class AuthorController : Controller
    {
        private string BaseURL = @"http://localhost:5000/api/author";    //"http://localhost:52727/api/author";

        // GET: AuthorController
        public async Task<IActionResult> Index()
        {
            List<Author> authorList = new List<Author>();
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(BaseURL))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    authorList = JsonConvert.DeserializeObject<List<Author>>(apiResponse);
                }
            }
            return View(authorList);
            
        }

        // GET: AuthorController/Details/5
        public async Task<IActionResult> Details(int id)
        {
            Author author = null;
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(BaseURL + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    author = JsonConvert.DeserializeObject<Author>(apiResponse);
                }
            }
            return View(author);
        }

        // GET: AuthorController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AuthorController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Author newAuthor)
        {
            try
            {
                StringContent content 
                    = new StringContent(JsonConvert.SerializeObject(newAuthor), 
                    Encoding.UTF8, "application/json");

                
                using (var httpClient = new HttpClient())
                {
                    var Response = await httpClient.PostAsync(BaseURL, content);
                }

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AuthorController/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            Author author = null;
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(BaseURL + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    author = JsonConvert.DeserializeObject<Author>(apiResponse);
                }
            }
            return View(author);
        }

        // POST: AuthorController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Author authorToUpdate)
        {
            try
            {
                StringContent content
                    = new StringContent(JsonConvert.SerializeObject(authorToUpdate),
                    Encoding.UTF8, "application/json");


                using (var httpClient = new HttpClient())
                {
                    var Response = await httpClient.PutAsync(BaseURL + "/" + id, content);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AuthorController/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            Author author = null;
            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync(BaseURL + "/" + id))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    author = JsonConvert.DeserializeObject<Author>(apiResponse);
                }
            }
            return View(author);
        }

        // POST: AuthorController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, IFormCollection collection)
        {
            try
            {
                using (var httpClient = new HttpClient())
                {
                    var Response = await httpClient.DeleteAsync(BaseURL + "/" + id);
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
