﻿namespace BookManagerMVCCoreAppCS.Models
{
    public class Author
    {
        public int authorID { get; set; }
        public string autherName { get; set; }
    }
}
