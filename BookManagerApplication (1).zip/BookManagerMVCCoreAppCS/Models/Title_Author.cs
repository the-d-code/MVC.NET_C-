﻿namespace BookManagerMVCCoreAppCS.Models
{
    public class Title_Author
    {
        public string Author { get; set; }
        public string Title { get; set; }
    }
}
